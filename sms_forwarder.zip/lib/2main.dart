import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:telephony/telephony.dart';
import 'package:permission_handler/permission_handler.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: _SmsForwarder(),
    );
  }
}

class _SmsForwarder extends StatefulWidget {
  @override
  _SmsForwarderState createState() => _SmsForwarderState();
}

class _SmsForwarderState extends State<_SmsForwarder> {
  final Telephony telephony = Telephony.instance;

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _listenForSms();
  }

  // Request SMS permissions
  Future<void> _requestPermissions() async {
    var status = await Permission.sms.request();
    if (status.isGranted) {
      log('Permission granted');
    } else {
      log('Permission denied');
    }
  }

  // Listen for incoming SMS messages
  void _listenForSms() async {
    telephony.listenIncomingSms(
      onNewMessage: (SmsMessage message) {
        //log message
        log("New SMS received: ${message.body}");
        // Forward the message to a predefined number
        _forwardSms(message);
      },
      onBackgroundMessage: backgroundMessageHandler,
      listenInBackground: true,
    );
  }

  static void backgroundMessageHandler(SmsMessage message) {
    log("Background SMS received: ${message.body}");
  }

  // Forward the SMS message
  void _forwardSms(SmsMessage message) async {
    // Replace this with the actual number you want to forward SMS to
    String forwardNumber = '9825929787';

    // Send the message to the forward number
    await telephony.sendSms(
      to: forwardNumber,
      message: 'Forwarded: ${message.body}',
    );
    log('SMS forwarded: ${message.body}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SMS Forwarder')),
      body: const Center(
        child: Text('Listening for SMS messages...'),
      ),
    );
  }
}
